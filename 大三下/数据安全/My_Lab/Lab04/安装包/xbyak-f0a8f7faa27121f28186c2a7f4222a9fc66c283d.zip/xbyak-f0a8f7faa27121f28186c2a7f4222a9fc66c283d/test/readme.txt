
test script on Windows

this test requires nasm.exe, yasm.exe, cl.exe, awk, diff

test_all ; for all tests
