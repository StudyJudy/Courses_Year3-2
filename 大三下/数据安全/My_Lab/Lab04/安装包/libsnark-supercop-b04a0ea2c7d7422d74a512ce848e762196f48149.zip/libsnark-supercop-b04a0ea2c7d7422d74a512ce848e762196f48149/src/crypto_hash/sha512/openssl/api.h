#include <openssl/rand.h>
#include <stddef.h>
#include <openssl/opensslv.h>
#define crypto_hash_sha512_openssl_VERSION OPENSSL_VERSION_TEXT
#define crypto_hash_sha512_openssl_BYTES 64
