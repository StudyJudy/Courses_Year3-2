#ifndef randombytes_h
#define randombytes_h

#ifdef __cplusplus
extern "C" {
#endif
extern void randombytes(unsigned char *,unsigned long long);
#ifdef __cplusplus
}
#endif

#endif
