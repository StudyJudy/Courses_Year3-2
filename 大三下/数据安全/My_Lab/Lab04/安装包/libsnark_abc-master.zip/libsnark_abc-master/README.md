# libsnark ABC

Minimal examples to use libsnark.

## Reference

- https://github.com/christianlundkvist/libsnark-tutorial
- https://github.com/howardwu/libsnark-tutorial